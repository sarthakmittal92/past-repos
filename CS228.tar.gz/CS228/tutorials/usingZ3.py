# load z3 library
from z3 import *

# declare boolean variables
# pythonName = Bool("variableName")
x = Bool("p1")
y = Bool("p2")

# construct formulae
phi = Or(x,y)
print(phi)

# allocate solver
s = Solver()

# add formulae to solver
s.add(phi)

# check for satisfiability
r = s.check()
print(r)

# check model
if r == sat:
    m = s.model()
    print(m)

# packaging
def solve (phi):
    print(phi)
    s = Solver()
    s.add(phi)
    r = s.check()
    print(r)
    if r == sat:
        m = s.model()
        print(m)

p1_p2 = And(x,y)
solve(p1_p2)

# sub-formulae
print(p1_p2.arg(0))

# symbol at the head
decl = p1_p2.decl()
print(decl)
name = decl.name()
print(name)