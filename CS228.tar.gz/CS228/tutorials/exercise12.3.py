from z3 import *
from mySolver import solve

a = Bool('a')
b = Bool('b')
c = Bool('c')

p1 = And(a,b)
p2 = Or(b,c)
p3 = And(a,c)
p4 = Not(Or(p2,p3))

d = Or(p1,p4)
solve(d)