# Solver function
from z3 import *

def solve (phi):
    print('Trying to solve:', phi)
    s = Solver()
    s.add(phi)
    r = s.check()
    print('Checking satisfiability... formula is', r)
    if r == sat:
        m = s.model()
        print('Satisfying model:', m)