# CS228

[Z3Py Tutorial](https://ericpony.github.io/z3py-tutorial/guide-examples.htm)

[Z3PracticeProblemsReference](https://drive.google.com/drive/folders/1n56Nc8T1ti4MNwblXOnDWU1rm3msbk0C?usp=sharing)

Some References:

https://ericpony.github.io/z3py-tutorial/guide-examples.htm

https://theory.stanford.edu/~nikolaj/programmingz3.html

https://github.com/Z3Prover/z3/tree/master/examples%2Fpython

https://www.programcreek.com/python/example/97293/z3.Solver

https://colab.research.google.com/github/philzook58/z3_tutorial/blob/master/Z3%20Tutorial.ipynb#scrollTo=pKKcoB-nwwxx

https://stackoverflow.com/questions/11867611/z3py-checking-all-solutions-for-equation
