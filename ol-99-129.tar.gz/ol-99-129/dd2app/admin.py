from django.contrib import admin
from dd2app.models import Profile

# Register your models here.
#admin.site.register(Profile)