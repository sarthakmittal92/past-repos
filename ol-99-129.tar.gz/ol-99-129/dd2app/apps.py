from django.apps import AppConfig

class Dd2AppConfig(AppConfig):
  default_auto_field = 'django.db.models.BigAutoField'
  name = 'dd2app'